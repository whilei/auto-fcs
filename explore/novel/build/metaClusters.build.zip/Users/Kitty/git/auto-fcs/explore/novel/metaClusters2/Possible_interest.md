Possible clusters of interest:
14